class OrderinAppConstant {
  static String baseURL = "http://192.168.0.103:8000/api/apieviasi";
  static String productgetURL = '${OrderinAppConstant.baseURL}/dataproduct';
  static String uploadURL = '${OrderinAppConstant.baseURL}/uploadproduct';
  static String updateURL = '${OrderinAppConstant.baseURL}/product';
}