 
  import 'dart:convert';
  import 'package:http/http.dart' as http;
 
  
 final String baseUrl = ''; // Ganti dengan URL server Anda


  // void main() async{
  //   var data = await signInWithGoogle('email@gmail.com');
  //   print(data);
  // }