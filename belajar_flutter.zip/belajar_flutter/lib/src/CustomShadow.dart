import 'package:belajar_flutter/src/CustomColors.dart';
import 'package:flutter/material.dart';

class CustomShadow{
  static Shadow TextShadow=  Shadow(color: CustomColors.blackColor,blurRadius: 10);
}