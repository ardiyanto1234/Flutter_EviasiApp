import 'package:flutter/material.dart';
class CustomColors {

static Color primaryColor = Color.fromRGBO(31, 31, 31, 1);
static Color secondaryColor= Color.fromRGBO(232, 25, 25, 1);
static Color whiteColor= Color.fromRGBO(255, 255, 255, 1);
static Color blackColor= Color.fromRGBO(0, 0, 0, 1);
static Color redEviasi= Color.fromRGBO(255, 113, 113, 1);
}